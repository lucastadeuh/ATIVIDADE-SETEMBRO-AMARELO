import * as React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

export default function Cartilha() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Transtornos mentais: você sabia que praticamente todas as pessoas que cometeram suicídio apresentavam pelo menos um transtorno psiquiátrico? Pessoas com depressão, transtorno bipolar, trantornos relacionados ao uso de drogas lícitas ou ilícitas(álcool, maconha, crack e cocaína, por exemplo), esquizofrenia e transtorno de personalidade fazem parte do grupo de risco. 
      </Text>
      <Text>CUIDE DO PROXIMO.</Text>
      <Image style={styles.logo} source={require('../assets/sa4.jpg')} />
      <Text style={styles.container}></Text>
      <Image style={styles.logo1} source={require('../assets/PDF1.jpg')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 130,
    width: 130,
  },
  logo1: {
    height: 94,
    width: 250,
  }
});
